# Algorithm Project — Greedy & Dynamic Programming

A Python + Web implementation of two classic algorithms:
1. **Task Scheduler** — Greedy (Job Sequencing with Deadlines)
2. **0/1 Knapsack** — Dynamic Programming

## Team Members
- Name 1 — Roll No.
- Name 2 — Roll No.
- Name 3 — Roll No.

## Algorithms Implemented

### 1. Task Scheduler (Greedy)
- Sort jobs by profit (descending)
- Assign each job to the latest free slot before its deadline
- Time Complexity: O(n log n + n × d)
- Space Complexity: O(d)  where d = max deadline

### 2. 0/1 Knapsack (DP)
- Build a 2D DP table of size (n+1) × (W+1)
- Each cell stores the max value for i items and weight limit w
- Traceback the table to find selected items
- Time Complexity: O(n × W)
- Space Complexity: O(n × W)

## Setup

```bash
pip install -r requirements.txt
```

## How to Run

### Web Interface (no setup needed)
Just open `index.html` in any browser.

### Command Line

Run both algorithms with sample data:
```bash
python src/main.py --input sample_input.json --chart
```

Run only greedy:
```bash
python src/main.py --mode greedy --input sample_input.json
```

Run only knapsack:
```bash
python src/main.py --mode knapsack --input sample_input.json
```

Compare greedy vs naive:
```bash
python src/main.py --mode greedy --input sample_input.json --compare --chart
```

Manual input (no JSON file):
```bash
python src/main.py
```

### Run Tests
```bash
python tests/test_scheduler.py
python tests/test_knapsack.py
```

## Complexity Analysis

| Algorithm     | Time           | Space    |
|---------------|----------------|----------|
| Greedy Sort   | O(n log n)     | O(1)     |
| Greedy Assign | O(n × d)       | O(d)     |
| DP Knapsack   | O(n × W)       | O(n × W) |

## Output Files Generated
- `greedy_gantt.png` — Gantt chart of the schedule
- `knapsack_chart.png` — bar chart of selected items
- `comparison_chart.png` — greedy vs naive comparison