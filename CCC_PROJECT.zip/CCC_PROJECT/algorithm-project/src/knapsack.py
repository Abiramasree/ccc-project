def knapsack_01(items, capacity):
    """
    0/1 Knapsack using Dynamic Programming.

    For each item, we decide: include it or leave it out.
    We build a 2D DP table where:
        dp[i][w] = max value using first i items with weight limit w

    Recurrence:
        If item weight > w:  dp[i][w] = dp[i-1][w]
        Else:                dp[i][w] = max(dp[i-1][w],
                                            dp[i-1][w - weight[i]] + value[i])

    Args:
        items    : list of dicts — each with 'id', 'weight', 'value'
        capacity : int — maximum weight the knapsack can hold

    Returns:
        max_value    : maximum value achievable
        chosen_items : list of items selected
        dp_table     : full DP table (for visualization)
    """
    if not items or capacity <= 0:
        return 0, [], []

    n = len(items)
    W = capacity

    # Build DP table of size (n+1) x (W+1), initialized to 0
    dp = [[0] * (W + 1) for _ in range(n + 1)]

    for i in range(1, n + 1):
        item = items[i - 1]
        for w in range(W + 1):
            # Option 1: don't take item i
            dp[i][w] = dp[i - 1][w]
            # Option 2: take item i (only if it fits)
            if item['weight'] <= w:
                take = dp[i - 1][w - item['weight']] + item['value']
                if take > dp[i][w]:
                    dp[i][w] = take

    # Traceback to find which items were chosen
    chosen_items = []
    w = W
    for i in range(n, 0, -1):
        if dp[i][w] != dp[i - 1][w]:
            chosen_items.append(items[i - 1])
            w -= items[i - 1]['weight']

    max_value = dp[n][W]
    return max_value, chosen_items, dp


def print_dp_table(dp, items, capacity):
    """Print the DP table in a readable grid format."""
    n = len(items)
    W = min(capacity, 15)  # limit display width

    print("\nDP TABLE (rows = items, columns = weight capacity 0 to", W, ")")
    print("-" * (W * 5 + 15))

    header = f"{'Item':<12}" + "".join(f"{w:>5}" for w in range(W + 1))
    print(header)
    print("-" * (W * 5 + 15))

    print(f"{'[empty]':<12}" + "".join(f"{dp[0][w]:>5}" for w in range(W + 1)))

    for i in range(1, n + 1):
        label = items[i - 1]['id'][:10]
        row = f"{label:<12}" + "".join(f"{dp[i][w]:>5}" for w in range(W + 1))
        print(row)

    print("-" * (W * 5 + 15))
    print(f"Max value (dp[{n}][{capacity}]) = {dp[n][capacity]}\n")