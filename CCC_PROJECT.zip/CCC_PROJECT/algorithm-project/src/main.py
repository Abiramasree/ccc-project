import json
import argparse
import sys
import os

# Make sure src/ is in the path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from scheduler import job_scheduler, naive_scheduler
from knapsack import knapsack_01, print_dp_table
from visualizer import (print_greedy_table, print_knapsack_result,
                        plot_greedy_gantt, plot_knapsack_bar, plot_comparison)


def load_json(filepath):
    with open(filepath, 'r') as f:
        return json.load(f)


def manual_jobs():
    print("\nEnter jobs manually. Type 'done' to finish.")
    jobs = []
    while True:
        job_id = input("  Job ID (or 'done'): ").strip()
        if job_id.lower() == 'done':
            break
        try:
            deadline = int(input(f"  Deadline for {job_id}: "))
            profit   = int(input(f"  Profit   for {job_id}: "))
            jobs.append({'id': job_id, 'deadline': deadline, 'profit': profit})
        except ValueError:
            print("  Enter integers only.")
    return jobs


def manual_items():
    print("\nEnter items manually. Type 'done' to finish.")
    items = []
    while True:
        item_id = input("  Item name (or 'done'): ").strip()
        if item_id.lower() == 'done':
            break
        try:
            weight = int(input(f"  Weight for {item_id} (kg): "))
            value  = int(input(f"  Value  for {item_id} (₹):  "))
            items.append({'id': item_id, 'weight': weight, 'value': value})
        except ValueError:
            print("  Enter integers only.")
    return items


def main():
    parser = argparse.ArgumentParser(description='Algorithm Project — Greedy + DP')
    parser.add_argument('--mode',    choices=['greedy', 'knapsack', 'both'], default='both')
    parser.add_argument('--input',   type=str, help='Path to JSON file')
    parser.add_argument('--compare', action='store_true', help='Compare greedy vs naive')
    parser.add_argument('--chart',   action='store_true', help='Show charts')
    args = parser.parse_args()

    print("\n" + "=" * 55)
    print("     ALGORITHM PROJECT — Greedy & DP Visualizer")
    print("=" * 55)

    data = {}
    if args.input:
        data = load_json(args.input)
        print(f"Loaded data from {args.input}")

    # ── GREEDY ────────────────────────────────────────────
    if args.mode in ('greedy', 'both'):
        print("\n[ MODE: Greedy Job Scheduler ]")
        jobs = data.get('jobs') if data.get('jobs') else manual_jobs()

        scheduled, slots, profit, skipped = job_scheduler(jobs)
        print_greedy_table(slots, scheduled, skipped, profit)

        if args.chart:
            plot_greedy_gantt(slots)

        if args.compare:
            _, _, n_profit, _ = naive_scheduler(jobs)
            n_scheduled, _, _, _ = naive_scheduler(jobs)
            plot_comparison(profit, n_profit, len(scheduled), len(n_scheduled))

    # ── KNAPSACK ──────────────────────────────────────────
    if args.mode in ('knapsack', 'both'):
        print("\n[ MODE: 0/1 Knapsack (DP) ]")
        items    = data.get('items') if data.get('items') else manual_items()
        capacity = data.get('capacity', None)
        if capacity is None:
            try:
                capacity = int(input("\nMax knapsack capacity (kg): "))
            except ValueError:
                capacity = 10

        max_val, chosen, dp_table = knapsack_01(items, capacity)
        print_dp_table(dp_table, items, capacity)
        print_knapsack_result(chosen, max_val, capacity)

        if args.chart:
            plot_knapsack_bar(items, chosen)


if __name__ == '__main__':
    main()