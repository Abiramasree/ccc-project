def job_scheduler(jobs):
    """
    Greedy Job Sequencing with Deadlines.
    Sorts jobs by profit (descending) and assigns each job
    to the latest available slot before its deadline.

    Args:
        jobs: list of dicts — each with 'id', 'deadline', 'profit'

    Returns:
        scheduled_jobs : list of jobs that were scheduled
        slots          : array — which job is in each time slot
        total_profit   : maximum profit achieved
        skipped_jobs   : jobs that could not be scheduled
    """
    if not jobs:
        return [], [], 0, []

    # Greedy choice: always pick the highest profit job first
    jobs_sorted = sorted(jobs, key=lambda x: x['profit'], reverse=True)

    max_deadline = max(job['deadline'] for job in jobs)
    slots = [None] * max_deadline

    scheduled_jobs = []
    skipped_jobs = []
    total_profit = 0

    for job in jobs_sorted:
        placed = False
        # Try to place in the latest free slot at or before deadline
        for t in range(job['deadline'] - 1, -1, -1):
            if slots[t] is None:
                slots[t] = job
                total_profit += job['profit']
                scheduled_jobs.append(job)
                placed = True
                break
        if not placed:
            skipped_jobs.append(job)

    return scheduled_jobs, slots, total_profit, skipped_jobs


def naive_scheduler(jobs):
    """
    Naive approach: sort by deadline instead of profit.
    Used only for comparison to show greedy is better.
    """
    if not jobs:
        return [], [], 0, []

    jobs_sorted = sorted(jobs, key=lambda x: x['deadline'])
    max_deadline = max(job['deadline'] for job in jobs)
    slots = [None] * max_deadline

    scheduled_jobs = []
    skipped_jobs = []
    total_profit = 0

    for job in jobs_sorted:
        placed = False
        for t in range(job['deadline'] - 1, -1, -1):
            if slots[t] is None:
                slots[t] = job
                total_profit += job['profit']
                scheduled_jobs.append(job)
                placed = True
                break
        if not placed:
            skipped_jobs.append(job)

    return scheduled_jobs, slots, total_profit, skipped_jobs