import matplotlib.pyplot as plt


def print_greedy_table(slots, scheduled_jobs, skipped_jobs, total_profit):
    """Print a formatted text schedule table for greedy results."""
    print("\n" + "=" * 55)
    print("        GREEDY TASK SCHEDULER — RESULTS")
    print("=" * 55)
    print(f"{'Slot':<12} {'Job ID':<15} {'Profit':>10}")
    print("-" * 55)

    for i, job in enumerate(slots):
        if job:
            print(f"{'Slot ' + str(i+1):<12} {job['id']:<15} {'₹' + str(job['profit']):>10}")
        else:
            print(f"{'Slot ' + str(i+1):<12} {'[Empty]':<15} {'-':>10}")

    print("-" * 55)
    print(f"{'Total Profit:':<27} {'₹' + str(total_profit):>10}")
    print(f"{'Jobs Scheduled:':<27} {len(scheduled_jobs):>10}")
    print(f"{'Jobs Skipped:':<27} {len(skipped_jobs):>10}")

    if skipped_jobs:
        print("\nSkipped Jobs:")
        for j in skipped_jobs:
            print(f"  - {j['id']}  (Profit: ₹{j['profit']}, Deadline: {j['deadline']})")
    print("=" * 55)


def print_knapsack_result(chosen_items, max_value, capacity):
    """Print knapsack result in a formatted table."""
    total_weight = sum(it['weight'] for it in chosen_items)

    print("\n" + "=" * 55)
    print("        0/1 KNAPSACK (DP) — RESULTS")
    print("=" * 55)
    print(f"{'Item':<15} {'Weight':>8} {'Value':>10}")
    print("-" * 55)

    for it in chosen_items:
        print(f"{it['id']:<15} {str(it['weight']) + ' kg':>8} {'₹' + str(it['value']):>10}")

    print("-" * 55)
    print(f"{'Total Weight:':<27} {str(total_weight) + ' / ' + str(capacity) + ' kg':>10}")
    print(f"{'Maximum Value:':<27} {'₹' + str(max_value):>10}")
    print("=" * 55)


def plot_greedy_gantt(slots):
    """Plot Gantt chart for the greedy schedule."""
    fig, ax = plt.subplots(figsize=(10, 3))
    colors = ['#00c896', '#00a07a', '#008a68', '#006e52']

    for i, job in enumerate(slots):
        color = colors[i % len(colors)] if job else '#2a2a3a'
        ax.barh(0, 1, left=i, color=color, edgecolor='#111', linewidth=0.8, height=0.5)
        label = f"{job['id']}\n₹{job['profit']}" if job else 'Free'
        ax.text(i + 0.5, 0, label, ha='center', va='center',
                fontsize=9, fontweight='bold', color='white')

    ax.set_xlim(0, len(slots))
    ax.set_ylim(-0.5, 0.5)
    ax.set_yticks([])
    ax.set_xticks(range(len(slots) + 1))
    ax.set_xticklabels([f'T{i}' for i in range(len(slots) + 1)])
    ax.set_title('Greedy Schedule — Gantt Chart', fontweight='bold')
    plt.tight_layout()
    plt.savefig('greedy_gantt.png', dpi=150)
    plt.show()
    print("Saved: greedy_gantt.png")


def plot_knapsack_bar(items, chosen_items):
    """Bar chart showing selected vs not-selected items."""
    chosen_ids = {it['id'] for it in chosen_items}
    names   = [it['id'] for it in items]
    values  = [it['value'] for it in items]
    colors  = ['#a78bfa' if it['id'] in chosen_ids else '#3a3a5a' for it in items]

    fig, ax = plt.subplots(figsize=(9, 4))
    bars = ax.bar(names, values, color=colors, edgecolor='#111', linewidth=0.8)

    for bar, item in zip(bars, items):
        ax.text(bar.get_x() + bar.get_width() / 2,
                bar.get_height() + 1,
                f"W:{item['weight']}", ha='center', va='bottom', fontsize=8)

    from matplotlib.patches import Patch
    legend = [Patch(color='#a78bfa', label='Selected'),
              Patch(color='#3a3a5a', label='Not Selected')]
    ax.legend(handles=legend)
    ax.set_title('0/1 Knapsack — Items (purple = selected)', fontweight='bold')
    ax.set_ylabel('Value (₹)')
    plt.tight_layout()
    plt.savefig('knapsack_chart.png', dpi=150)
    plt.show()
    print("Saved: knapsack_chart.png")


def plot_comparison(g_profit, n_profit, g_count, n_count):
    """Compare greedy vs naive approach side by side."""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4))

    ax1.bar(['Greedy', 'Naive'], [g_profit, n_profit],
            color=['#00c896', '#e74c3c'], edgecolor='#111', linewidth=0.8)
    ax1.set_title('Profit Comparison', fontweight='bold')
    ax1.set_ylabel('Profit (₹)')
    for i, v in enumerate([g_profit, n_profit]):
        ax1.text(i, v + max(g_profit, n_profit) * 0.02,
                 f'₹{v}', ha='center', fontweight='bold')

    ax2.bar(['Greedy', 'Naive'], [g_count, n_count],
            color=['#3b82f6', '#f97316'], edgecolor='#111', linewidth=0.8)
    ax2.set_title('Jobs Scheduled', fontweight='bold')
    ax2.set_ylabel('Count')
    for i, v in enumerate([g_count, n_count]):
        ax2.text(i, v + 0.1, str(v), ha='center', fontweight='bold')

    plt.suptitle('Greedy vs Naive Approach', fontsize=13, fontweight='bold')
    plt.tight_layout()
    plt.savefig('comparison_chart.png', dpi=150)
    plt.show()
    print("Saved: comparison_chart.png")