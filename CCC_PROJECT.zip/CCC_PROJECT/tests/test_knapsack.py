import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))
from knapsack import knapsack_01


def test_basic():
    items = [
        {'id': 'A', 'weight': 2, 'value': 6},
        {'id': 'B', 'weight': 2, 'value': 10},
        {'id': 'C', 'weight': 3, 'value': 12},
    ]
    val, chosen, _ = knapsack_01(items, 5)
    assert val == 22, f"Expected 22, got {val}"
    print("test_basic PASSED")


def test_nothing_fits():
    items = [{'id': 'X', 'weight': 10, 'value': 100}]
    val, chosen, _ = knapsack_01(items, 5)
    assert val == 0
    assert chosen == []
    print("test_nothing_fits PASSED")


def test_all_fit():
    items = [
        {'id': 'A', 'weight': 1, 'value': 10},
        {'id': 'B', 'weight': 1, 'value': 20},
    ]
    val, chosen, _ = knapsack_01(items, 5)
    assert val == 30
    assert len(chosen) == 2
    print("test_all_fit PASSED")


def test_zero_capacity():
    items = [{'id': 'A', 'weight': 1, 'value': 10}]
    val, chosen, _ = knapsack_01(items, 0)
    assert val == 0
    print("test_zero_capacity PASSED")


def test_empty_items():
    val, chosen, _ = knapsack_01([], 10)
    assert val == 0
    print("test_empty_items PASSED")


if __name__ == '__main__':
    test_basic()
    test_nothing_fits()
    test_all_fit()
    test_zero_capacity()
    test_empty_items()
    print("\nAll knapsack tests passed!")