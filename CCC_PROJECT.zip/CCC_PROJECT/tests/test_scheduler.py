import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))
from scheduler import job_scheduler, naive_scheduler


def test_basic():
    jobs = [
        {'id': 'A', 'deadline': 2, 'profit': 100},
        {'id': 'B', 'deadline': 1, 'profit': 19},
        {'id': 'C', 'deadline': 2, 'profit': 27},
        {'id': 'D', 'deadline': 1, 'profit': 25},
    ]
    _, _, profit, _ = job_scheduler(jobs)
    assert profit == 127, f"Expected 127, got {profit}"
    print("test_basic PASSED")


def test_single_slot():
    jobs = [
        {'id': 'X', 'deadline': 1, 'profit': 10},
        {'id': 'Y', 'deadline': 1, 'profit': 80},
        {'id': 'Z', 'deadline': 1, 'profit': 30},
    ]
    scheduled, _, profit, _ = job_scheduler(jobs)
    assert profit == 80
    assert scheduled[0]['id'] == 'Y'
    print("test_single_slot PASSED")


def test_all_fit():
    jobs = [
        {'id': 'A', 'deadline': 1, 'profit': 10},
        {'id': 'B', 'deadline': 2, 'profit': 20},
        {'id': 'C', 'deadline': 3, 'profit': 30},
    ]
    scheduled, _, profit, skipped = job_scheduler(jobs)
    assert profit == 60
    assert len(skipped) == 0
    print("test_all_fit PASSED")


def test_empty():
    scheduled, slots, profit, skipped = job_scheduler([])
    assert profit == 0 and scheduled == []
    print("test_empty PASSED")


def test_greedy_beats_naive():
    jobs = [
        {'id': 'A', 'deadline': 2, 'profit': 100},
        {'id': 'B', 'deadline': 1, 'profit': 19},
        {'id': 'C', 'deadline': 2, 'profit': 27},
        {'id': 'D', 'deadline': 1, 'profit': 25},
    ]
    _, _, g = job_scheduler(jobs)
    _, _, n = naive_scheduler(jobs)
    assert g >= n
    print(f"test_greedy_beats_naive PASSED — Greedy ₹{g} vs Naive ₹{n}")


if __name__ == '__main__':
    test_basic()
    test_single_slot()
    test_all_fit()
    test_empty()
    test_greedy_beats_naive()
    print("\nAll scheduler tests passed!")